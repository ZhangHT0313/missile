#ifndef __TIM_H__
#define __TIM_H__
#include "stm32f4xx.h"

void TIM5_Configuration(void);

#endif
