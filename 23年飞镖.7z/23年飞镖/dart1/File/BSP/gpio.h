#ifndef __GPIO_H__
#define __GPIO_H__

#include "global.h"
#include "hitcrt_types.h"

void GPIO_Configuration(void);

#endif
