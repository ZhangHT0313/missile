#ifndef __USART_H__
#define __USART_H__

#include "global.h"
#include "hitcrt_types.h"

void USART3_Configuration(void);
void USART2_Configuration(void);
void UART4_Configuration(void);
void UART5_Configuration(void);

#endif
