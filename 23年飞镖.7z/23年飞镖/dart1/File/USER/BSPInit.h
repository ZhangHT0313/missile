#ifndef __BSPINIT_H__
#define __BSPINIT_H__

#include "sys.h"
#include "tim.h"
#include "can.h"
#include "pwm.h"
#include "usart.h"
#include "gpio.h"

void Bsp_Init(void);


#endif
