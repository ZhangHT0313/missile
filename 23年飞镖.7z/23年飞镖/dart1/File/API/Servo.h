#ifndef __SERVO_H__
#define __SERVO_H__

#include "global.h"


void Servo_procontrol(void);


#endif
