#ifndef __RC_CONTROL_H__
#define __RC_CONTROL_H__

#include "global.h"
#include "hitcrt_types.h"


void RemoteDataProcess(uint8_t *pData);

#endif

