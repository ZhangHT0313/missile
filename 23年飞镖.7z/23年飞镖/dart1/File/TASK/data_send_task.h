#ifndef __DATA_SEND_TASK_H__
#define __DATA_SEND_TASK_H__

#include "global.h"
#include "hitcrt_types.h"
#include "dji_protocal.h"

void Send_Data_To_MainControl2(void);
void Send_Data_To_Sensor1(void);
void Send_Data_To_Sensor2(void);

#endif
