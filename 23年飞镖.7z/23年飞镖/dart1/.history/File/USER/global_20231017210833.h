#ifndef __GLOBAL_H__
#define __GLOBAL_H__
#include "stm32f4xx.h"                  // Device header
#include "hitcrt_types.h"

extern SystemMonitor_struct ledmonitor;
extern uint16_t ledpwm_counter;

#endif
