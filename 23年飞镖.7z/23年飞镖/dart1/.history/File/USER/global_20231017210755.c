#include "stm32f4xx.h"                  // Device header
#include "global.h"

SystemMonitor_struct ledmonitor={0};

uint16_t ledpwm_counter = 0;
