#ifndef __USART_H__
#define __USART_H__

#include "global.h"
#include "hitcrt_types.h"

void USART2_Configuration(void);

#endif
